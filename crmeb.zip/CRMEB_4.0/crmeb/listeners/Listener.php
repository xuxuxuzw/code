<?php

namespace crmeb\listeners;

use crmeb\interfaces\ListenerInterface;

class Listener implements ListenerInterface
{

    public function handle($event): void
    {

    }
}
