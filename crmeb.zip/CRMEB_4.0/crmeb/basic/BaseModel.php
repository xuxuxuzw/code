<?php
/**
 *
 * @author: xaboy<365615158@qq.com>
 * @day: 2017/11/02
 */

namespace crmeb\basic;

use crmeb\traits\ModelTrait;
use think\Model;

/**
 * Class BaseModel
 * @package crmeb\basic
 * @mixin ModelTrait
 */
class BaseModel extends Model
{

}
