<?php

return [
    \app\AppService::class,
];